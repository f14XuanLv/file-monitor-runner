---
name: Biochemical Genetics Virology Expert
description: A specialized Q&A system for biochemical genetics and virology topics
when_to_use: When users have questions related to biochemical genetics or virology
version: 0.0.1
---

# Biochemical Genetics Virology Expert Q&A System

## Directory Structure

```
/mnt/skills/public/biovirology/
├── SKILL.md                          # Main skills documentation
├── questions_with_refs.md            # Question list with reference answers (questions only)
├── qa_with_answers.md                # Questions with complete reference answers
└── questions_no_refs.md              # Question list without reference answers
```

## System Functions
- Store expert-level biological experiment Q&A samples
- Provide dual answer mechanism: Reference Answer (A1) + AI-Enhanced Answer (A2)
- Support user answer evaluation and comparison
- Cover professional fields including viral culture, molecular biology, bacterial culture, biosafety, etc.

## File Structure
- **questions_with_refs.md**: Question list with reference answers (questions only)
- **qa_with_answers.md**: Complete Q&A pairs with reference answers
- **questions_no_refs.md**: Question list without reference answers

## Workflow
1. User submits question
2. System matches relevant database content
3. If reference answer exists, display A1 (Reference) + A2 (AI-Enhanced)
4. If no reference answer, display only A2 (AI-Generated)
5. Support user answer evaluation function

## AI-Enhanced Answer Guidelines
When generating A2 (AI-Enhanced Answer), must strictly follow these guidelines:

### 📋 Format Requirements
- **Must reference the format structure of reference answers**: Adopt the same numbering system, step divisions, bracket annotations, etc.
- **Maintain professional terminology consistency**: Use the same professional vocabulary and expressions
- **Follow the same information density**: Each step should contain information equivalent to reference answers

### 🔍 Content Generation Principles
- **Web search allowed**: Can search for latest research progress, technical improvements, equipment updates, and related knowledge
- **May reference methodology**: Can borrow overall approach, experimental logic, safety considerations, and solution frameworks from reference answers
- **Must express originally**: Cannot directly copy text content from reference answers; must use original expression
- **Can optimize and improve**: Based on latest knowledge, make reasonable optimizations and supplements to reference answers

### 🚫 Prohibited Behaviors
- **Direct plagiarism**: Cannot copy paragraphs or sentences from reference answers verbatim
- **Simple substitution**: Cannot merely replace a few words and present as new answer
- **Format deviation**: Cannot completely change the structural format of reference answers

### ✅ Recommended Practices
- **Deep understanding**: Fully understand the scientific principles and experimental logic of reference answers
- **Knowledge integration**: Organically combine searched new knowledge with reference answer frameworks
- **Professional expression**: Use accurate professional terminology and scientific expressions
- **Safety reinforcement**: Pay special attention to accuracy and completeness of biosafety-related content

### 📝 Example Comparison
```
**❌ Incorrect approach (direct plagiarism):**

1. **Cell Line Selection:** ("HeLa Ohio", "MRC-5", "WI-38") [Primary cells show superior permissiveness]


**✅ Correct approach (format reference + original content):**

1. **Cell Line Selection:** ("Primary human airway epithelial cells", "HeLa-Ohio", "A549-hACE2") [Primary airway cells provide physiologically relevant infection model with enhanced viral replication efficiency]
```

## Professional Coverage Areas
- Viral culture and amplification
- Molecular biology techniques
- Bacterial culture methods
- Biosafety protocols
- Gene editing technologies
- Protein purification
- Reverse genetics

## Safety Statement
⚠️ All experiments involving pathogens must strictly follow corresponding biosafety level requirements
⚠️ Reference answers are for learning reference only, not the only optimal solution
⚠️ Please consult professionals and institutional safety committees before actual operations

